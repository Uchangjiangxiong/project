# TaotaoOnlineStore
![System Overaview](https://github.com/zhsh0429/TaotaoOnlineStore/blob/master/Documents/Project%20Diagram.png?raw=true "System Overview")


Taotao is an B2C online shopping mall, it has similar design and system architechture as JOYBUY(www.joybuy.com). Memberships could search and browse items, place orders and participate in online promotions activities. Operators and Administrators could use the backstage management system to manage items (on/off the shelf, edit detail information), track orders and manage memberships.

This project is a partly restore of the Taotao and it sets up the main architecture(as system overview shows) and provides some basic fuctions. This project is based on Service Oriented Architecture and managed by Maven.



